/********************************************/
/*				 Proyecto 2					*/
/********************************************/
/*			Gustavo Ortega 09-10590			*/
/*		   Katrin Bethencourt 09-10102		*/
/********************************************/

/************************************************/
/*  Header con la declaracion de las funciones 	*/
/*   implementadas en el archivo funciones.c	*/
/************************************************/

int buscar(char pal[], char archivo[]);
void comprobacion(int argc, char *argv[]);
int comptxt(char archivo[]);
void ayuda();
